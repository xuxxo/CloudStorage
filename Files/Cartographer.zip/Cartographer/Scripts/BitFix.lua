function common.GetBitAnd( value, value2 )
	return bit.band( value, value2 )
end

function common.GetBitOr( value, value2 )
	return bit.bor( value, value2 )
end

function common.GetBitXor( value, value2 )
	return bit.bxor( value, value2 )
end