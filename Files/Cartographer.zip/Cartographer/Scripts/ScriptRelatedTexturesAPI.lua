--------------------------------------------------------------------------------
local function def_equal( v1, v2 ) return v1 == v2 end
--------------------------------------------------------------------------------
-- Поиск по таблице полным перебором, можно задать свой компаратор
local function table_search( tab, entry, equal )
	equal = equal or def_equal
	for k, v in pairs( tab ) do
		if equal( v, entry ) then
			return true, k
		end
	end
	return false
end
--------------------------------------------------------------------------------
-- Texture caches
--------------------------------------------------------------------------------
local _textureDefaultGroupId = "Common"
local _dummyGroup = { HasTexture = function() return false end }
local _textureAddonGroups = {}
local _textureAddonCache = {}
local _textureStateGroups = {}
local _textureStateCache = {}
--------------------------------------------------------------------------------
local function GetGroupTexture( group, groupCache, sysName, optional )
	local result = groupCache[ sysName ]
	if result == nil then
		local hasTexture = group:HasTexture( sysName )
		if hasTexture then
			result = group:GetTexture( sysName )
		elseif optional then
			result = false
		---BEGIN_DEBUG---
		else
			local _, sysGroup = table_search( _textureAddonGroups, group )
			if not sysGroup then
				_, sysGroup = table_search( _textureStateGroups, group )
			end
			if group == _dummyGroup then
				error( string.format( "Requested texture [%s] from non-existent group [%s]", tostring( sysName ), tostring( sysGroup ) ) )
			else
				error( string.format( "Requested non-existent texture [%s] from group [%s]", tostring( sysName ), tostring( sysGroup ) ) )
			end
		---END_DEBUG---
		end
		groupCache[ sysName ] = result
	end
	return result
end
--------------------------------------------------------------------------------
-- Получить текстуру sysName из группы аддона sysGroup (или Common если nil)
-- Если задано optional то отсутствие текстуры не считается ошибкой
function GetAddonTexture( sysGroup, sysName, optional )
	sysGroup = sysGroup or _textureDefaultGroupId
	local group = _textureAddonGroups[ sysGroup ]
	if not group then
		group = common.GetAddonRelatedTextureGroup( sysGroup, true ) or _dummyGroup
		_textureAddonGroups[ sysGroup ] = group
		_textureAddonCache[ sysGroup ] = {}
	end
	return GetGroupTexture( group, _textureAddonCache[ sysGroup ], sysName, optional )
end
--------------------------------------------------------------------------------
-- Получить текстуру sysName из группы стейта sysGroup (или Common если nil)
-- Если задано optional то отсутствие текстуры не считается ошибкой
function GetStateTexture( sysGroup, sysName, optional )
	sysGroup = sysGroup or _textureDefaultGroupId
	local group = _textureStateGroups[ sysGroup ]
	if not group then
		group = common.GetStateRelatedTextureGroup( sysGroup, true ) or _dummyGroup
		_textureStateGroups[ sysGroup ] = group
		_textureStateCache[ sysGroup ] = {}
	end
	return GetGroupTexture( group, _textureStateCache[ sysGroup ], sysName, optional )
end
--------------------------------------------------------------------------------
-- BONUS: Old API convert
--------------------------------------------------------------------------------
local GetAddonTexture, GetStateTexture = GetAddonTexture, GetStateTexture
--------------------------------------------------------------------------------
function common.GetAddonRelatedTexture( sysName )
	return GetAddonTexture( nil, sysName )
end
--------------------------------------------------------------------------------
function common.GetAddonRelatedGroupTexture( sysGroup, sysName )
	return GetAddonTexture( sysGroup, sysName )
end
--------------------------------------------------------------------------------
function common.GetStateRelatedTexture( sysName )
	return GetStateTexture( nil, sysName )
end
--------------------------------------------------------------------------------
function common.GetStateRelatedGroupTexture( sysGroup, sysName )
	return GetStateTexture( sysGroup, sysName )
end
--------------------------------------------------------------------------------
