local GetApiType = common.GetApiType

local IsWString = common.IsWString
local IsValuedText = common.IsValuedText

local function checkWString(v)
	if not IsWString(v) then
		error(('param 1 not a class WString (type: %s)'):format(GetApiType(v)))
	end
	return v
end

local function checkValuedText(v)
	if not IsValuedText(v) then
		error(('param 1 not a class ValuedText (type: %s)'):format(GetApiType(v)))
	end
	return v
end

function common.GetWStringLength(text)
	return #checkWString(text)
end

function common.GetIntFromWString(text)
	return checkWString(text):ToInt()
end

function common.GetShortString(text)
	return checkWString(text):ToAbbr()
end

function common.TruncateWString(text, maxOverallLen, trailingDotsCount, needTrim)
	return checkWString(text):Truncate(maxOverallLen, trailingDotsCount, needTrim)
end

local function compare(a, b, ignoreRegistry)
	if not IsWString(a) or not IsWString(b) then return -1 end
	local r = a:Compare(b, ignoreRegistry)
	return r > 0 and 1 or r < 0 and -1 or r
end

function common.CompareWString(a, b)
	return compare(a, b)
end

function common.CompareWStringEx(a, b)
	return compare(a, b, true)
end

function common.IsSubstring(text, part)
	return checkWString(text):IsContain(part)
end

function common.IsSubstringEx(text, part)
	return checkWString(text):IsContain(part, true)
end

function common.IsEmptyWString(text)
	return checkWString(text):IsEmpty()
end

function common.IsEmptyValuedText(valuedText)
	return checkValuedText(valuedText):IsEmpty()
end

function common.ExtractWStringFromValuedText(valuedText)
	return checkValuedText(valuedText):ToWString()
end

function common.SetTextValues(object, textValues)
	local f = object and object.SetTextValues
	if not f then
		error(('param 1 (type: %s) not meet the given condition'):format(GetApiType(object)))
	end
	f(object, textValues)
end
