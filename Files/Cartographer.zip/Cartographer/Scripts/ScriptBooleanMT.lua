local _getmetatable = getmetatable

function getmetatable(v)
	local mt = _getmetatable(v)
	return type(mt) == 'boolean' and {} or mt
end